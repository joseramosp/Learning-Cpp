* Jose Ramos
* Student ID: 00299444
* C++ Programming Language - CIS 240
* February 16 of 2020
* Problem Set 3
---------------------------

* Objective:

Problem sets may be worked collaboratively. You are welcome to talk solutions in the discussion boards. They are graded on participation, not correctness.

Correct solutions to specific problems may be requested after due dates.

Ch 4 and 5

exercises

4.28
4.34
4.36
5.30
5.33
5.35


Submit your solutions in an organized way. Be sure they are clearly documented and commented.

* NOTE: Please change the "CMakeLists.txt" file to select the main Problem that you want to run. Just uncomment the one that you want to run and
  comment all the others.

* Citations: None.
