* Jose Ramos
* Student ID: 00299444
* C++ Programming Language - CIS 240
* February 9 of 2020
* Problem Set 2
---------------------------

* Objective:

Problem sets may be worked collaboratively. You are welcome to talk solutions in the discussion boards. They are graded on participation, not correctness.

Correct solutions to specific problems may be requested after due dates.

Ch 3

3.9
3.10
3.11
3.13
3.14

Submit your solutions in an organized way. Be sure they are clearly documented and commented.

* NOTE: Please change the "CMakeLists.txt" file to select the main Problem that you want to run. Just uncomment the one that you want to run and
  comment all the others.

* Citations: None.
