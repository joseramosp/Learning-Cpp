//
// Created by Jose Ramos on 2/29/20.
//

// 8.10 (Function Headers and Prototypes) Perform the task in each of the following:
// A. Write the function header for function zero that takes a long integer built-in array parameter bigIntegers and a
//    second parameter representing the array’s size and does not return a value.
// B. Write the function prototype for the function in part (a).
// C. Write the function header for function add1AndSum that takes an integer built-in array parameter oneTooSmall and
//    a second parameter representing the array’s size and returns an integer.
// D. Write the function prototype for the function described in part (c).

#include <iostream>
#include <cstdlib>
#include <array>

using namespace std;

void zero(long bigIntegers[], int size);
int add1AndSum(int oneTooSmall[], int size);

int main() {

    return 0;
}

void zero(long bigIntegers[], int size){

}

int add1AndSum(int oneTooSmall[], int size){

    return 0;
}