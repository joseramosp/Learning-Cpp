//
// Created by Jose Ramos on 4/7/20.
//

#ifndef PROBLEM_SET_7_PERSON_H
#define PROBLEM_SET_7_PERSON_H


class Person {

};


#endif //PROBLEM_SET_7_PERSON_H
