//
// Created by Jose Ramos on 4/7/20.
//

#ifndef PROBLEM_SET_7_RATIONAL_H
#define PROBLEM_SET_7_RATIONAL_H


class Rational {

};


#endif //PROBLEM_SET_7_RATIONAL_H
