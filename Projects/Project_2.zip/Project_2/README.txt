* Jose Ramos
* Student ID: 00299444
* C++ Programming Language - CIS 240
* March 25 of 2020
* Project 2
---------------------------

* Objective:

Design, implement and test the following components of Risk:

Die (should be completed)
Card
Deck of Cards
Player - with cards in hand, can roll a number of die
Submit all classes and test files. 

* NOTE: 

In order to run the graphics, make sure you have the working directory set as the project folder.

The most difficult part was dealing with the duplicated declaration errors because of including classes that where inherence when importing another class.

* Citations:

I downloaded the SFML library from here -> https://www.sfml-dev.org/download/csfml/ 