* Jose Ramos
* Student ID: 00299444
* C++ Programming Language - CIS 240
* February 19 of 2020
* Project 1
---------------------------

* Objective:

For at least the next two projects, we are going to be designing and building the a game of Risk.

To start, read all about risk here https://gamerules.com/rules/risk-board-game/

While you read about the game, consider what kinds of classes you may need to model the game - a Territory, Dice, a Card...

Draw UML class diagrams for your design. Write a brief description description of your plan for how these classes interact.
Define a Die class and a DieTester Class that creates some die and rolls them.
OPTIONAL:

As we build this game, you may want to try to use some graphics. While not required, I am happy top support you trying. 

Check out the Simple Fast Media Library and set it up if you can - https://www.sfml-dev.org

Submit your UML charts and your Die class and tester. 

* NOTE: 

The most difficult part was doing the make file and installing the SFML.

* Citations: https://www.sfml-dev.org/download/csfml/ (I downloaded the sfml from this website).
